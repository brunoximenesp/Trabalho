package musica;

public class Pessoa {
	
	public String nome;

}
