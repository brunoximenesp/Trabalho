package musica;

import javax.swing.JOptionPane;

public class TesteMusica {
	
	public static void main(String[] args) {
		Album album1 = new Album("Thriller");
		Artista artista1 = new Artista("Michael Jackson");
		Musica musica1 = new Musica("Beat It", "It doesn't matter who's wrong or right");
		Musica musica2 = new Musica("Thriller", "It's close to midnight");
		
		album1.artista = artista1;
		album1.addMusica(musica1);
		album1.addMusica(musica2);
		
		String letra = JOptionPane.showInputDialog("Digite a letra da m�sica: ");
		
		String resultado = album1.acharMusica(letra);
		JOptionPane.showMessageDialog(null, resultado);
		
	}

}
