package musica;

public class Musica {
	
	public String nome;
	
	public String letra;
	
	public Musica(String nome, String letra) {
		this.nome = nome;
		this.letra = letra;
	}
	
	public boolean checarLetra(String letraUsuario) {
		return letra.toLowerCase().contains(letraUsuario.toLowerCase());
	}
	
	public String toString() {
		return this.nome;
	}

}
