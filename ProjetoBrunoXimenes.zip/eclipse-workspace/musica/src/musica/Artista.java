package musica;

public class Artista extends Pessoa {
	
	public Artista(String nome) {
		this.nome = nome;
	}
	
	public String toString() {
		return this.nome;
	}

}
