package musica;

import java.util.ArrayList;
import java.util.List;

public class Album {
	
	public String nome;
	
	public Artista artista;
	
	public List<Musica> musicas = new ArrayList<>();
	
	public Album(String nome) {
		this.nome = nome;
	}
	
	public void addMusica(Musica musica) {
		this.musicas.add(musica);
	}
	
	public String acharMusica(String letra) {
		for (Musica musica : musicas) {
			boolean contemLetra = musica.checarLetra(letra);
			if(contemLetra) {
				return "M�sica: " + musica.toString() + "\n" + this.toString();
			}
		}
		return "M�sica n�o encontrada";
	}
	
	public String toString() {
		return "�lbum: " + this.nome + " - " + this.artista.toString();
	}

}
